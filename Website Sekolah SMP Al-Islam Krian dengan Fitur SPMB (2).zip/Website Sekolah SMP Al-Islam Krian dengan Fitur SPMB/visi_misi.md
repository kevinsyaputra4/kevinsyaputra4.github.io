# Visi & Misi

**Visi:**

Terwujudnya peserta didik yang beriman, bertaqwa, berakhlak mulia, cerdas, terampil, dan berdaya saing global.

**Misi:**

1.  Menyelenggarakan pendidikan yang berlandaskan iman dan taqwa.
2.  Mengembangkan potensi peserta didik secara optimal.
3.  Meningkatkan kualitas pembelajaran yang inovatif dan kreatif.
4.  Membentuk karakter peserta didik yang berakhlak mulia.
5.  Mempersiapkan peserta didik untuk menghadapi tantangan global.

