<?php
require_once '../config.php';
require_once '../functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

// Get statistics
try {
    $pdo = getConnection();
    
    // Total registrations
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM students");
    $totalRegistrations = $stmt->fetch()['total'];
    
    // Pending registrations
    $stmt = $pdo->query("SELECT COUNT(*) as pending FROM students WHERE status = 'pending'");
    $pendingRegistrations = $stmt->fetch()['pending'];
    
    // Approved registrations
    $stmt = $pdo->query("SELECT COUNT(*) as approved FROM students WHERE status = 'approved'");
    $approvedRegistrations = $stmt->fetch()['approved'];
    
    // Recent registrations
    $stmt = $pdo->query("SELECT * FROM students ORDER BY registration_date DESC LIMIT 10");
    $recentRegistrations = $stmt->fetchAll();
    
} catch(PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SMP AL-ISLAM KRIAN</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #f8f9fa;
            color: #333;
        }

        .admin-header {
            background: linear-gradient(135deg, #2c5530, #4a7c59);
            color: white;
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .admin-nav {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .admin-logo {
            font-size: 1.5rem;
            font-weight: 700;
        }

        .admin-user {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logout-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 20px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .logout-btn:hover {
            background: rgba(255,255,255,0.3);
        }

        .admin-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 30px 20px;
        }

        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            text-align: center;
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #2c5530, #4a7c59);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            color: white;
            font-size: 1.5rem;
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: #2c5530;
            margin-bottom: 5px;
        }

        .stat-label {
            color: #666;
            font-size: 0.9rem;
        }

        .recent-registrations {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            overflow: hidden;
        }

        .section-header {
            padding: 25px 30px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .section-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: #2c5530;
        }

        .view-all-btn {
            background: linear-gradient(135deg, #2c5530, #4a7c59);
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 20px;
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .view-all-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(44, 85, 48, 0.3);
        }

        .registrations-table {
            width: 100%;
            border-collapse: collapse;
        }

        .registrations-table th,
        .registrations-table td {
            padding: 15px 20px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        .registrations-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }

        .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
        }

        .status-pending {
            background: #fff3cd;
            color: #856404;
        }

        .status-approved {
            background: #d4edda;
            color: #155724;
        }

        .status-rejected {
            background: #f8d7da;
            color: #721c24;
        }

        .action-btn {
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.8rem;
            margin: 0 2px;
            transition: all 0.3s ease;
        }

        .btn-view {
            background: #007bff;
            color: white;
        }

        .btn-approve {
            background: #28a745;
            color: white;
        }

        .btn-reject {
            background: #dc3545;
            color: white;
        }

        .action-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }

        @media (max-width: 768px) {
            .admin-nav {
                flex-direction: column;
                gap: 15px;
            }

            .dashboard-stats {
                grid-template-columns: 1fr;
            }

            .registrations-table {
                font-size: 0.9rem;
            }

            .registrations-table th,
            .registrations-table td {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <header class="admin-header">
        <nav class="admin-nav">
            <div class="admin-logo">
                <i class="fas fa-graduation-cap"></i>
                Admin Dashboard - SMP AL-ISLAM KRIAN
            </div>
            <div class="admin-user">
                <span><i class="fas fa-user"></i> <?php echo $_SESSION['admin_name']; ?></span>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </nav>
    </header>

    <div class="admin-container">
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- Dashboard Statistics -->
        <div class="dashboard-stats">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-number"><?php echo $totalRegistrations; ?></div>
                <div class="stat-label">Total Pendaftaran</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="stat-number"><?php echo $pendingRegistrations; ?></div>
                <div class="stat-label">Menunggu Verifikasi</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-number"><?php echo $approvedRegistrations; ?></div>
                <div class="stat-label">Diterima</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-calendar"></i>
                </div>
                <div class="stat-number"><?php echo date('Y'); ?></div>
                <div class="stat-label">Tahun Ajaran</div>
            </div>
        </div>

        <!-- Recent Registrations -->
        <div class="recent-registrations">
            <div class="section-header">
                <h2 class="section-title">Pendaftaran Terbaru</h2>
                <a href="registrations.php" class="view-all-btn">
                    <i class="fas fa-eye"></i> Lihat Semua
                </a>
            </div>
            <table class="registrations-table">
                <thead>
                    <tr>
                        <th>No. Pendaftaran</th>
                        <th>Nama Lengkap</th>
                        <th>Tanggal Daftar</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($recentRegistrations)): ?>
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 40px;">
                                <i class="fas fa-inbox" style="font-size: 2rem; color: #ccc; margin-bottom: 10px;"></i>
                                <p>Belum ada pendaftaran</p>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($recentRegistrations as $registration): ?>
                            <tr>
                                <td><?php echo $registration['registration_number']; ?></td>
                                <td><?php echo $registration['full_name']; ?></td>
                                <td><?php echo formatDate($registration['registration_date']); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo $registration['status']; ?>">
                                        <?php 
                                        switch($registration['status']) {
                                            case 'pending': echo 'Menunggu'; break;
                                            case 'approved': echo 'Diterima'; break;
                                            case 'rejected': echo 'Ditolak'; break;
                                        }
                                        ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="action-btn btn-view" onclick="viewRegistration('<?php echo $registration['id']; ?>')">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <?php if ($registration['status'] === 'pending'): ?>
                                        <button class="action-btn btn-approve" onclick="updateStatus('<?php echo $registration['id']; ?>', 'approved')">
                                            <i class="fas fa-check"></i>
                                        </button>
                                        <button class="action-btn btn-reject" onclick="updateStatus('<?php echo $registration['id']; ?>', 'rejected')">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function viewRegistration(id) {
            window.open('view_registration.php?id=' + id, '_blank', 'width=800,height=600');
        }

        function updateStatus(id, status) {
            if (confirm('Apakah Anda yakin ingin mengubah status pendaftaran ini?')) {
                fetch('update_status.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'id=' + id + '&status=' + status
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Terjadi kesalahan sistem');
                });
            }
        }
    </script>
</body>
</html>

