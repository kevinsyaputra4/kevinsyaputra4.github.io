<?php
require_once 'config.php';

// Function to sanitize input
function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

// Function to generate registration number
function generateRegistrationNumber() {
    $year = date('Y');
    $month = date('m');
    
    try {
        $pdo = getConnection();
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM students WHERE YEAR(registration_date) = ?");
        $stmt->execute([$year]);
        $result = $stmt->fetch();
        
        $sequence = str_pad($result['count'] + 1, 4, '0', STR_PAD_LEFT);
        return "SMP{$year}{$month}{$sequence}";
    } catch(PDOException $e) {
        return "SMP{$year}{$month}0001";
    }
}

// Function to upload file
function uploadFile($file, $targetDir = 'uploads/') {
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }
    
    $fileName = time() . '_' . basename($file['name']);
    $targetFile = $targetDir . $fileName;
    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    
    // Check file size (max 5MB)
    if ($file['size'] > 5000000) {
        return ['success' => false, 'message' => 'File terlalu besar. Maksimal 5MB.'];
    }
    
    // Allow certain file formats
    $allowedTypes = ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx'];
    if (!in_array($fileType, $allowedTypes)) {
        return ['success' => false, 'message' => 'Format file tidak diizinkan.'];
    }
    
    if (move_uploaded_file($file['tmp_name'], $targetFile)) {
        return ['success' => true, 'filename' => $fileName];
    } else {
        return ['success' => false, 'message' => 'Gagal mengupload file.'];
    }
}

// Function to get news
function getNews($limit = null, $status = 'published') {
    try {
        $pdo = getConnection();
        $sql = "SELECT n.*, a.full_name as author_name 
                FROM news n 
                LEFT JOIN admin a ON n.author_id = a.id 
                WHERE n.status = ? 
                ORDER BY n.published_at DESC";
        
        if ($limit) {
            $sql .= " LIMIT " . intval($limit);
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$status]);
        return $stmt->fetchAll();
    } catch(PDOException $e) {
        return [];
    }
}

// Function to get single news by slug
function getNewsBySlug($slug) {
    try {
        $pdo = getConnection();
        $stmt = $pdo->prepare("SELECT n.*, a.full_name as author_name 
                              FROM news n 
                              LEFT JOIN admin a ON n.author_id = a.id 
                              WHERE n.slug = ? AND n.status = 'published'");
        $stmt->execute([$slug]);
        return $stmt->fetch();
    } catch(PDOException $e) {
        return false;
    }
}

// Function to get achievements
function getAchievements($limit = null) {
    try {
        $pdo = getConnection();
        $sql = "SELECT * FROM achievements ORDER BY year DESC, created_at DESC";
        
        if ($limit) {
            $sql .= " LIMIT " . intval($limit);
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch(PDOException $e) {
        return [];
    }
}

// Function to get facilities
function getFacilities($status = 'active') {
    try {
        $pdo = getConnection();
        $stmt = $pdo->prepare("SELECT * FROM facilities WHERE status = ? ORDER BY name");
        $stmt->execute([$status]);
        return $stmt->fetchAll();
    } catch(PDOException $e) {
        return [];
    }
}

// Function to get teachers
function getTeachers($status = 'active') {
    try {
        $pdo = getConnection();
        $stmt = $pdo->prepare("SELECT * FROM teachers WHERE status = ? ORDER BY position, full_name");
        $stmt->execute([$status]);
        return $stmt->fetchAll();
    } catch(PDOException $e) {
        return [];
    }
}

// Function to save student registration
function saveStudentRegistration($data) {
    try {
        $pdo = getConnection();
        
        $sql = "INSERT INTO students (
            registration_number, full_name, nickname, gender, place_of_birth, date_of_birth,
            religion, nationality, address, phone, email, previous_school,
            father_name, father_job, father_phone, mother_name, mother_job, mother_phone,
            guardian_name, guardian_phone, guardian_address, photo, birth_certificate,
            family_card, report_card
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute([
            $data['registration_number'], $data['full_name'], $data['nickname'],
            $data['gender'], $data['place_of_birth'], $data['date_of_birth'],
            $data['religion'], $data['nationality'], $data['address'],
            $data['phone'], $data['email'], $data['previous_school'],
            $data['father_name'], $data['father_job'], $data['father_phone'],
            $data['mother_name'], $data['mother_job'], $data['mother_phone'],
            $data['guardian_name'], $data['guardian_phone'], $data['guardian_address'],
            $data['photo'], $data['birth_certificate'], $data['family_card'], $data['report_card']
        ]);
        
        if ($result) {
            return ['success' => true, 'registration_number' => $data['registration_number']];
        } else {
            return ['success' => false, 'message' => 'Gagal menyimpan data pendaftaran.'];
        }
    } catch(PDOException $e) {
        return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
    }
}

// Function to get student by registration number
function getStudentByRegistrationNumber($regNumber) {
    try {
        $pdo = getConnection();
        $stmt = $pdo->prepare("SELECT * FROM students WHERE registration_number = ?");
        $stmt->execute([$regNumber]);
        return $stmt->fetch();
    } catch(PDOException $e) {
        return false;
    }
}

// Function to save contact message
function saveContactMessage($data) {
    try {
        $pdo = getConnection();
        $stmt = $pdo->prepare("INSERT INTO contact_messages (name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)");
        $result = $stmt->execute([$data['name'], $data['email'], $data['phone'], $data['subject'], $data['message']]);
        
        if ($result) {
            return ['success' => true, 'message' => 'Pesan berhasil dikirim.'];
        } else {
            return ['success' => false, 'message' => 'Gagal mengirim pesan.'];
        }
    } catch(PDOException $e) {
        return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
    }
}

// Function to get setting value
function getSetting($key, $default = '') {
    try {
        $pdo = getConnection();
        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $result = $stmt->fetch();
        
        return $result ? $result['setting_value'] : $default;
    } catch(PDOException $e) {
        return $default;
    }
}

// Function to format date
function formatDate($date, $format = 'd F Y') {
    $months = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
    ];
    
    $timestamp = strtotime($date);
    $day = date('d', $timestamp);
    $month = $months[date('n', $timestamp)];
    $year = date('Y', $timestamp);
    
    return "$day $month $year";
}

// Function to create slug
function createSlug($string) {
    $string = strtolower($string);
    $string = preg_replace('/[^a-z0-9\s-]/', '', $string);
    $string = preg_replace('/[\s-]+/', '-', $string);
    return trim($string, '-');
}

// Function to send email (basic implementation)
function sendEmail($to, $subject, $message, $from = null) {
    if (!$from) {
        $from = getSetting('school_email', 'admin@smpalislam-krian.sch.id');
    }
    
    $headers = "From: " . getSetting('school_name', 'SMP AL-ISLAM KRIAN') . " <$from>\r\n";
    $headers .= "Reply-To: $from\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    
    return mail($to, $subject, $message, $headers);
}

// Function to validate email
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

// Function to validate phone number
function isValidPhone($phone) {
    return preg_match('/^[0-9+\-\s()]{10,20}$/', $phone);
}

// Function to check if registration is open
function isRegistrationOpen() {
    $isOpen = getSetting('registration_open', '1');
    $startDate = getSetting('registration_start', date('Y-01-01'));
    $endDate = getSetting('registration_end', date('Y-12-31'));
    
    $now = date('Y-m-d');
    
    return $isOpen == '1' && $now >= $startDate && $now <= $endDate;
}
?>

