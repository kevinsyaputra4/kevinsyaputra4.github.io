<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'smp_al_islam_krian');

// Create connection
function getConnection() {
    try {
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8", DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch(PDOException $e) {
        die("Connection failed: " . $e->getMessage());
    }
}

// Site configuration
define('SITE_NAME', 'SMP AL-ISLAM KRIAN');
define('SITE_URL', 'http://localhost');
define('ADMIN_EMAIL', 'admin@smpalislam-krian.sch.id');

// Session configuration
session_start();

// Timezone
date_default_timezone_set('Asia/Jakarta');
?>

