<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

try {
    $registrationNumber = sanitize($_POST['registration_number'] ?? '');
    
    if (empty($registrationNumber)) {
        echo json_encode(['success' => false, 'message' => 'Nomor pendaftaran wajib diisi']);
        exit;
    }

    // Get student data
    $student = getStudentByRegistrationNumber($registrationNumber);

    if ($student) {
        // Format the response
        $response = [
            'success' => true,
            'found' => true,
            'data' => [
                'registration_number' => $student['registration_number'],
                'full_name' => $student['full_name'],
                'status' => $student['status'],
                'registration_date' => $student['registration_date'],
                'notes' => $student['notes'] ?? ''
            ]
        ];

        // Add additional info based on status
        switch ($student['status']) {
            case 'pending':
                $response['data']['status_message'] = 'Pendaftaran Anda sedang dalam proses verifikasi. Mohon tunggu pengumuman lebih lanjut.';
                break;
            case 'approved':
                $response['data']['status_message'] = 'Selamat! Pendaftaran Anda telah diterima. Silakan datang ke sekolah untuk proses selanjutnya.';
                break;
            case 'rejected':
                $response['data']['status_message'] = 'Mohon maaf, pendaftaran Anda belum dapat kami terima. Silakan hubungi sekolah untuk informasi lebih lanjut.';
                break;
        }

        echo json_encode($response);
    } else {
        echo json_encode([
            'success' => true,
            'found' => false,
            'message' => 'Nomor pendaftaran tidak ditemukan'
        ]);
    }

} catch (Exception $e) {
    error_log("Status check error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Terjadi kesalahan sistem']);
}
?>

