# Sejarah Sekolah

SMP Al-Islam Krian didirikan pada 1964 oleh Anam Mahmud dan Sry Soeparto untuk memberikan pendidikan Islam bagi masyarakat Krian. Sekolah ini berlokasi di Jl. Kyai Mojo No.18 Jerukgamping, Krian.

