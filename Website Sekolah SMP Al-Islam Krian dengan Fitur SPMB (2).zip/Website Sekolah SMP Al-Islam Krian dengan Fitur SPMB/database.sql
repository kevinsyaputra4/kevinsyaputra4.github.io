-- Database: smp_al_islam_krian

CREATE DATABASE IF NOT EXISTS smp_al_islam_krian;
USE smp_al_islam_krian;

-- Table: admin
CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Table: students (for SPMB)
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    registration_number VARCHAR(20) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    nickname VARCHAR(50),
    gender ENUM('L', 'P') NOT NULL,
    place_of_birth VARCHAR(50) NOT NULL,
    date_of_birth DATE NOT NULL,
    religion VARCHAR(20) NOT NULL,
    nationality VARCHAR(30) DEFAULT 'Indonesia',
    address TEXT NOT NULL,
    phone VARCHAR(20),
    email VARCHAR(100),
    previous_school VARCHAR(100) NOT NULL,
    father_name VARCHAR(100) NOT NULL,
    father_job VARCHAR(100),
    father_phone VARCHAR(20),
    mother_name VARCHAR(100) NOT NULL,
    mother_job VARCHAR(100),
    mother_phone VARCHAR(20),
    guardian_name VARCHAR(100),
    guardian_phone VARCHAR(20),
    guardian_address TEXT,
    photo VARCHAR(255),
    birth_certificate VARCHAR(255),
    family_card VARCHAR(255),
    report_card VARCHAR(255),
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT
);

-- Table: news
CREATE TABLE news (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    slug VARCHAR(200) UNIQUE NOT NULL,
    content TEXT NOT NULL,
    excerpt TEXT,
    featured_image VARCHAR(255),
    author_id INT,
    status ENUM('draft', 'published') DEFAULT 'draft',
    published_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES admin(id)
);

-- Table: achievements
CREATE TABLE achievements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    category VARCHAR(50),
    level VARCHAR(50),
    year YEAR,
    achiever_name VARCHAR(100),
    image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table: facilities
CREATE TABLE facilities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    image VARCHAR(255),
    status ENUM('active', 'maintenance', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table: teachers
CREATE TABLE teachers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nip VARCHAR(30),
    full_name VARCHAR(100) NOT NULL,
    subject VARCHAR(100),
    position VARCHAR(100),
    education VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(100),
    photo VARCHAR(255),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table: contact_messages
CREATE TABLE contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    subject VARCHAR(200),
    message TEXT NOT NULL,
    status ENUM('unread', 'read', 'replied') DEFAULT 'unread',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table: settings
CREATE TABLE settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default admin user
INSERT INTO admin (username, password, email, full_name) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@smpalislam-krian.sch.id', 'Administrator');

-- Insert sample news
INSERT INTO news (title, slug, content, excerpt, status, published_at) VALUES 
('Selamat Datang di SMP AL-ISLAM Krian', 'selamat-datang-di-smp-al-islam-krian', 
'Tahun ajaran baru telah dimulai dengan semangat dan antusiasme tinggi dari seluruh civitas akademika SMP AL-ISLAM Krian. Kami menyambut siswa-siswa baru dengan berbagai program unggulan yang telah disiapkan.', 
'Tahun ajaran baru telah dimulai dengan semangat dan antusiasme tinggi dari seluruh civitas akademika SMP AL-ISLAM Krian.', 
'published', NOW()),

('Implementasi Kurikulum Merdeka', 'implementasi-kurikulum-merdeka', 
'SMP AL-ISLAM Krian berkomitmen menerapkan kurikulum merdeka untuk memberikan pembelajaran yang lebih bermakna dan sesuai dengan kebutuhan siswa di era modern.', 
'SMP AL-ISLAM Krian berkomitmen menerapkan kurikulum merdeka untuk memberikan pembelajaran yang lebih bermakna.', 
'published', NOW()),

('Prestasi Gemilang di Kompetisi Basket', 'prestasi-gemilang-di-kompetisi-basket', 
'Tim basket SMP AL-ISLAM Krian meraih juara pertama dalam kompetisi antar sekolah tingkat kabupaten. Prestasi ini merupakan hasil dari latihan keras dan dedikasi para siswa.', 
'Tim basket SMP AL-ISLAM Krian meraih juara pertama dalam kompetisi antar sekolah tingkat kabupaten.', 
'published', NOW());

-- Insert sample achievements
INSERT INTO achievements (title, description, category, level, year, achiever_name) VALUES 
('Juara 1 Lomba Pidato Bahasa Inggris', 'Prestasi gemilang dalam lomba pidato bahasa Inggris tingkat kabupaten', 'Akademik', 'Kabupaten', 2023, 'Nur Inayah'),
('Juara 1 Kompetisi Bola Basket', 'Meraih juara pertama dalam kompetisi bola basket antar SMP', 'Olahraga', 'Kabupaten', 2023, 'Tim Basket'),
('Juara Umum Kompetisi Sepak Bola', 'Prestasi membanggakan dalam liga sepak bola tingkat kabupaten', 'Olahraga', 'Kabupaten', 2023, 'Tim Sepak Bola');

-- Insert sample facilities
INSERT INTO facilities (name, description) VALUES 
('Laboratorium IPA', 'Laboratorium lengkap untuk praktikum fisika, kimia, dan biologi'),
('Lab Komputer', 'Ruang komputer dengan perangkat terbaru untuk pembelajaran TIK'),
('Perpustakaan', 'Koleksi buku lengkap dan ruang baca yang nyaman'),
('Lapangan Olahraga', 'Lapangan basket, futsal, dan area olahraga lainnya'),
('Ruang Seni', 'Studio seni dan teater untuk mengembangkan bakat siswa'),
('Musholla', 'Tempat ibadah yang nyaman untuk kegiatan keagamaan');

-- Insert sample teachers
INSERT INTO teachers (full_name, subject, position) VALUES 
('Drs. Vulkan Abriyanto', 'Kepala Sekolah', 'Kepala Sekolah'),
('Yayun Ciuss S.Pd', 'Seni Rupa', 'Guru Seni Rupa'),
('Nur Rosalina', 'Biologi', 'Guru Biologi'),
('Rama Sofyan Hadi', 'IPA Kimia', 'Guru IPA Kimia'),
('Siti Romlah', 'Geografi', 'Guru Geografi');

-- Insert default settings
INSERT INTO settings (setting_key, setting_value, description) VALUES 
('school_name', 'SMP AL-ISLAM KRIAN', 'Nama sekolah'),
('school_address', 'Jl. Kyai Mojo No.18 Jerukgamping, Krian, Sidoarjo, Jawa Timur', 'Alamat sekolah'),
('school_phone', '(031) 8971281', 'Nomor telepon sekolah'),
('school_email', 'admin@smpalislam-krian.sch.id', 'Email sekolah'),
('registration_open', '1', 'Status pendaftaran (1=buka, 0=tutup)'),
('registration_start', '2024-01-01', 'Tanggal mulai pendaftaran'),
('registration_end', '2024-06-30', 'Tanggal akhir pendaftaran');

