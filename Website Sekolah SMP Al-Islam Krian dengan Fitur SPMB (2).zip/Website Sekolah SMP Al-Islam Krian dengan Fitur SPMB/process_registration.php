<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

try {
    // Check if registration is open
    if (!isRegistrationOpen()) {
        echo json_encode(['success' => false, 'message' => 'Pendaftaran sedang ditutup']);
        exit;
    }

    // Validate required fields
    $requiredFields = [
        'full_name', 'gender', 'place_of_birth', 'date_of_birth', 
        'religion', 'address', 'previous_school', 'father_name', 'mother_name'
    ];

    foreach ($requiredFields as $field) {
        if (empty($_POST[$field])) {
            echo json_encode(['success' => false, 'message' => "Field $field wajib diisi"]);
            exit;
        }
    }

    // Validate email if provided
    if (!empty($_POST['email']) && !isValidEmail($_POST['email'])) {
        echo json_encode(['success' => false, 'message' => 'Format email tidak valid']);
        exit;
    }

    // Validate phone numbers if provided
    $phoneFields = ['phone', 'father_phone', 'mother_phone', 'guardian_phone'];
    foreach ($phoneFields as $field) {
        if (!empty($_POST[$field]) && !isValidPhone($_POST[$field])) {
            echo json_encode(['success' => false, 'message' => "Format nomor telepon $field tidak valid"]);
            exit;
        }
    }

    // Generate registration number
    $registrationNumber = generateRegistrationNumber();

    // Prepare data for database
    $studentData = [
        'registration_number' => $registrationNumber,
        'full_name' => sanitize($_POST['full_name']),
        'nickname' => sanitize($_POST['nickname'] ?? ''),
        'gender' => sanitize($_POST['gender']),
        'place_of_birth' => sanitize($_POST['place_of_birth']),
        'date_of_birth' => $_POST['date_of_birth'],
        'religion' => sanitize($_POST['religion']),
        'nationality' => sanitize($_POST['nationality'] ?? 'Indonesia'),
        'address' => sanitize($_POST['address']),
        'phone' => sanitize($_POST['phone'] ?? ''),
        'email' => sanitize($_POST['email'] ?? ''),
        'previous_school' => sanitize($_POST['previous_school']),
        'father_name' => sanitize($_POST['father_name']),
        'father_job' => sanitize($_POST['father_job'] ?? ''),
        'father_phone' => sanitize($_POST['father_phone'] ?? ''),
        'mother_name' => sanitize($_POST['mother_name']),
        'mother_job' => sanitize($_POST['mother_job'] ?? ''),
        'mother_phone' => sanitize($_POST['mother_phone'] ?? ''),
        'guardian_name' => sanitize($_POST['guardian_name'] ?? ''),
        'guardian_phone' => sanitize($_POST['guardian_phone'] ?? ''),
        'guardian_address' => sanitize($_POST['guardian_address'] ?? ''),
        'photo' => '',
        'birth_certificate' => '',
        'family_card' => '',
        'report_card' => ''
    ];

    // Handle file uploads
    $uploadDir = 'uploads/students/' . $registrationNumber . '/';
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $fileFields = ['photo', 'birth_certificate', 'family_card', 'report_card'];
    foreach ($fileFields as $field) {
        if (isset($_FILES[$field]) && $_FILES[$field]['error'] === UPLOAD_ERR_OK) {
            $uploadResult = uploadFile($_FILES[$field], $uploadDir);
            if ($uploadResult['success']) {
                $studentData[$field] = $uploadDir . $uploadResult['filename'];
            } else {
                echo json_encode(['success' => false, 'message' => "Error uploading $field: " . $uploadResult['message']]);
                exit;
            }
        }
    }

    // Save to database
    $result = saveStudentRegistration($studentData);

    if ($result['success']) {
        // Send confirmation email if email is provided
        if (!empty($studentData['email'])) {
            $subject = 'Konfirmasi Pendaftaran SMP AL-ISLAM KRIAN';
            $message = "
                <h2>Konfirmasi Pendaftaran</h2>
                <p>Terima kasih telah mendaftar di SMP AL-ISLAM KRIAN.</p>
                <p><strong>Nomor Pendaftaran:</strong> {$registrationNumber}</p>
                <p><strong>Nama:</strong> {$studentData['full_name']}</p>
                <p><strong>Tanggal Pendaftaran:</strong> " . date('d F Y') . "</p>
                <p>Silakan simpan nomor pendaftaran ini untuk keperluan pengecekan status.</p>
                <p>Untuk informasi lebih lanjut, hubungi kami di (031) 8971281.</p>
                <br>
                <p>Salam,<br>Panitia SPMB SMP AL-ISLAM KRIAN</p>
            ";
            
            sendEmail($studentData['email'], $subject, $message);
        }

        echo json_encode([
            'success' => true, 
            'message' => 'Pendaftaran berhasil dikirim',
            'registration_number' => $registrationNumber
        ]);
    } else {
        echo json_encode($result);
    }

} catch (Exception $e) {
    error_log("Registration error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Terjadi kesalahan sistem']);
}
?>

