# Website SMP AL-ISLAM KRIAN

Website sekolah modern dengan fitur SPMB (Seleksi Penerimaan Siswa Baru) menggunakan PHP dan MySQL.

## Fitur Utama

### Frontend
- **Desain Modern**: Website responsif dengan desain trend 2025
- **Halaman Utama**: Informasi lengkap tentang sekolah
- **Profil Sekolah**: Sejarah, visi misi, struktur organisasi
- **Program Akademik**: Kurikulum dan program unggulan
- **Fasilitas**: Daftar fasilitas sekolah dengan gambar
- **Berita & Kegiatan**: Informasi terkini sekolah
- **Prestasi**: Pencapaian siswa dan sekolah
- **Kontak**: Informasi kontak dengan peta lokasi terintegrasi

### SPMB (Seleksi Penerimaan Siswa Baru)
- **Formulir Pendaftaran Online**: Form lengkap dengan validasi
- **Upload Dokumen**: Sistem upload untuk dokumen persyaratan
- **Cek Status**: Fitur untuk mengecek status pendaftaran
- **Notifikasi Email**: Konfirmasi pendaftaran otomatis
- **Auto-save**: Penyimpanan otomatis data form

### Backend & Admin
- **Dashboard Admin**: Panel kontrol untuk mengelola pendaftaran
- **Manajemen Siswa**: CRUD data siswa dan status pendaftaran
- **Database MySQL**: Struktur database lengkap
- **API Endpoints**: RESTful API untuk frontend-backend communication

## Teknologi yang Digunakan

- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Backend**: PHP 7.4+
- **Database**: MySQL 5.7+
- **Styling**: Custom CSS dengan animasi modern
- **Icons**: Font Awesome 6.0
- **Maps**: Google Maps Embed API

## Struktur File

```
smp_al_islam_krian_website/
├── index.html              # Halaman utama
├── spmb.html              # Halaman SPMB
├── styles.css             # CSS utama
├── spmb.css              # CSS khusus SPMB
├── script.js             # JavaScript utama
├── spmb.js               # JavaScript SPMB
├── config.php            # Konfigurasi database
├── functions.php         # Fungsi-fungsi PHP
├── process_registration.php  # Proses pendaftaran
├── check_status.php      # Cek status pendaftaran
├── database.sql          # Struktur database
├── admin/                # Panel admin
│   └── index.php         # Dashboard admin
├── assets/               # Gambar dan aset
│   ├── logo.png
│   ├── smp_school_building.png
│   ├── smp_students_learning.png
│   └── smp_students_activity.png
└── uploads/              # Folder upload dokumen
```

## Instalasi

### 1. Persiapan Database
```sql
-- Import file database.sql ke MySQL
mysql -u root -p < database.sql
```

### 2. Konfigurasi
Edit file `config.php` sesuai dengan pengaturan database Anda:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
define('DB_NAME', 'smp_al_islam_krian');
```

### 3. Permissions
Pastikan folder `uploads/` memiliki permission write:
```bash
chmod 755 uploads/
```

### 4. Web Server
- Upload semua file ke web server
- Pastikan PHP dan MySQL sudah terinstall
- Akses website melalui browser

## Fitur SPMB

### Pendaftaran Online
1. **Data Pribadi Siswa**
   - Nama lengkap, nama panggilan
   - Jenis kelamin, tempat/tanggal lahir
   - Agama, kewarganegaraan
   - Alamat, nomor telepon, email
   - Asal sekolah

2. **Data Orang Tua**
   - Nama ayah/ibu
   - Pekerjaan ayah/ibu
   - Nomor telepon ayah/ibu

3. **Data Wali** (opsional)
   - Nama wali
   - Nomor telepon wali
   - Alamat wali

4. **Upload Dokumen**
   - Pas foto 3x4
   - Akta kelahiran
   - Kartu keluarga
   - Rapor SD

### Validasi Form
- Validasi real-time untuk semua field
- Validasi format email dan nomor telepon
- Validasi ukuran dan format file upload
- Validasi usia siswa (10-20 tahun)

### Fitur Tambahan
- Auto-save form data ke localStorage
- Preview gambar yang diupload
- Nomor pendaftaran otomatis
- Status tracking dengan warna

## Admin Panel

### Login Admin
- Username: `admin`
- Password: `password` (hash: `$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi`)

### Dashboard Features
- Statistik pendaftaran
- Daftar pendaftaran terbaru
- Update status pendaftaran
- View detail pendaftaran

## API Endpoints

### POST /process_registration.php
Memproses pendaftaran siswa baru
```json
{
  "success": true,
  "message": "Pendaftaran berhasil dikirim",
  "registration_number": "SMP202501001"
}
```

### POST /check_status.php
Mengecek status pendaftaran
```json
{
  "success": true,
  "found": true,
  "data": {
    "registration_number": "SMP202501001",
    "full_name": "Nama Siswa",
    "status": "pending",
    "registration_date": "2025-01-15",
    "status_message": "Pendaftaran sedang dalam proses verifikasi"
  }
}
```

## Database Schema

### Tabel Utama
- `students`: Data siswa dan pendaftaran
- `admin`: Data administrator
- `news`: Berita dan kegiatan
- `achievements`: Prestasi sekolah
- `facilities`: Fasilitas sekolah
- `teachers`: Data guru dan staff
- `contact_messages`: Pesan kontak
- `settings`: Pengaturan sistem

## Keamanan

- Input sanitization untuk semua data
- Prepared statements untuk query database
- File upload validation
- Session management untuk admin
- CSRF protection (recommended untuk production)

## Responsive Design

Website fully responsive dengan breakpoints:
- Desktop: 1200px+
- Tablet: 768px - 1199px
- Mobile: < 768px

## Browser Support

- Chrome 80+
- Firefox 75+
- Safari 13+
- Edge 80+

## Maintenance

### Backup Database
```bash
mysqldump -u username -p smp_al_islam_krian > backup.sql
```

### Clear Upload Files
Bersihkan file upload lama secara berkala untuk menghemat storage.

### Update Content
- Edit data sekolah melalui admin panel
- Update gambar di folder `assets/`
- Modify content di file HTML

## Support

Untuk pertanyaan dan dukungan teknis, hubungi:
- Email: admin@smpalislam-krian.sch.id
- Telepon: (031) 8971281

## License

© 2025 SMP AL-ISLAM KRIAN. All rights reserved.

