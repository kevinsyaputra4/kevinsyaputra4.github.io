// SPMB JavaScript Functions

document.addEventListener('DOMContentLoaded', function() {
    initSPMBForm();
    initStatusCheck();
});

// Initialize SPMB Registration Form
function initSPMBForm() {
    const form = document.getElementById('registrationForm');
    if (!form) return;

    form.addEventListener('submit', handleFormSubmission);
    
    // Add real-time validation
    const requiredFields = form.querySelectorAll('[required]');
    requiredFields.forEach(field => {
        field.addEventListener('blur', validateField);
        field.addEventListener('input', clearFieldError);
    });

    // Format phone numbers
    const phoneFields = form.querySelectorAll('input[type="tel"]');
    phoneFields.forEach(field => {
        field.addEventListener('input', function() {
            window.SMP_Utils.formatPhoneNumber(this);
        });
    });

    // File upload validation
    const fileInputs = form.querySelectorAll('input[type="file"]');
    fileInputs.forEach(input => {
        input.addEventListener('change', validateFileUpload);
    });
}

// Handle form submission
async function handleFormSubmission(e) {
    e.preventDefault();
    
    const form = e.target;
    const submitBtn = form.querySelector('.submit-btn');
    
    // Validate form
    if (!window.SMP_Utils.validateForm(form)) {
        window.SMP_Utils.showNotification('Mohon lengkapi semua field yang wajib diisi', 'error');
        return;
    }

    // Check terms agreement
    const termsCheckbox = form.querySelector('#terms');
    if (!termsCheckbox.checked) {
        window.SMP_Utils.showNotification('Mohon setujui syarat dan ketentuan', 'error');
        return;
    }

    // Show loading state
    window.SMP_Utils.addLoadingState(submitBtn);

    try {
        // Prepare form data
        const formData = new FormData(form);
        
        // Generate registration number (in real implementation, this would be done server-side)
        const registrationNumber = generateRegistrationNumber();
        formData.append('registration_number', registrationNumber);

        // Simulate API call (replace with actual endpoint)
        const response = await submitRegistration(formData);
        
        if (response.success) {
            showSuccessModal(registrationNumber);
            form.reset();
        } else {
            window.SMP_Utils.showNotification(response.message || 'Terjadi kesalahan saat mengirim pendaftaran', 'error');
        }
    } catch (error) {
        console.error('Registration error:', error);
        window.SMP_Utils.showNotification('Terjadi kesalahan sistem. Silakan coba lagi.', 'error');
    }
}

// Simulate registration submission
async function submitRegistration(formData) {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Simulate success response
    return {
        success: true,
        message: 'Pendaftaran berhasil dikirim',
        registration_number: formData.get('registration_number')
    };
}

// Generate registration number (client-side simulation)
function generateRegistrationNumber() {
    const year = new Date().getFullYear();
    const month = String(new Date().getMonth() + 1).padStart(2, '0');
    const random = Math.floor(Math.random() * 9999) + 1;
    const sequence = String(random).padStart(4, '0');
    
    return `SMP${year}${month}${sequence}`;
}

// Validate individual field
function validateField(e) {
    const field = e.target;
    const value = field.value.trim();
    
    // Remove existing error state
    field.classList.remove('error');
    
    // Check if required field is empty
    if (field.hasAttribute('required') && !value) {
        field.classList.add('error');
        return false;
    }
    
    // Validate email
    if (field.type === 'email' && value && !window.SMP_Utils.isValidEmail(value)) {
        field.classList.add('error');
        window.SMP_Utils.showNotification('Format email tidak valid', 'error');
        return false;
    }
    
    // Validate phone
    if (field.type === 'tel' && value && !window.SMP_Utils.isValidPhone(value)) {
        field.classList.add('error');
        window.SMP_Utils.showNotification('Format nomor telepon tidak valid', 'error');
        return false;
    }
    
    // Validate date of birth (must be at least 10 years old)
    if (field.name === 'date_of_birth' && value) {
        const birthDate = new Date(value);
        const today = new Date();
        const age = today.getFullYear() - birthDate.getFullYear();
        
        if (age < 10 || age > 20) {
            field.classList.add('error');
            window.SMP_Utils.showNotification('Usia harus antara 10-20 tahun', 'error');
            return false;
        }
    }
    
    return true;
}

// Clear field error state
function clearFieldError(e) {
    e.target.classList.remove('error');
}

// Validate file upload
function validateFileUpload(e) {
    const file = e.target.files[0];
    if (!file) return;
    
    const maxSize = e.target.name === 'photo' ? 2 * 1024 * 1024 : 5 * 1024 * 1024; // 2MB for photo, 5MB for others
    const allowedTypes = e.target.name === 'photo' 
        ? ['image/jpeg', 'image/png'] 
        : ['image/jpeg', 'image/png', 'application/pdf'];
    
    // Check file size
    if (file.size > maxSize) {
        window.SMP_Utils.showNotification(`Ukuran file terlalu besar. Maksimal ${maxSize / (1024 * 1024)}MB`, 'error');
        e.target.value = '';
        return;
    }
    
    // Check file type
    if (!allowedTypes.includes(file.type)) {
        window.SMP_Utils.showNotification('Format file tidak didukung', 'error');
        e.target.value = '';
        return;
    }
    
    // Show file preview for images
    if (file.type.startsWith('image/')) {
        showImagePreview(e.target, file);
    }
}

// Show image preview
function showImagePreview(input, file) {
    const reader = new FileReader();
    reader.onload = function(e) {
        // Remove existing preview
        const existingPreview = input.parentNode.querySelector('.file-preview');
        if (existingPreview) {
            existingPreview.remove();
        }
        
        // Create preview element
        const preview = document.createElement('div');
        preview.className = 'file-preview';
        preview.innerHTML = `
            <img src="${e.target.result}" alt="Preview" style="max-width: 100px; max-height: 100px; margin-top: 10px; border-radius: 5px;">
            <p style="font-size: 0.8rem; color: #666; margin-top: 5px;">${file.name}</p>
        `;
        
        input.parentNode.appendChild(preview);
    };
    reader.readAsDataURL(file);
}

// Initialize status check functionality
function initStatusCheck() {
    const statusForm = document.getElementById('statusForm');
    if (!statusForm) return;
    
    statusForm.addEventListener('submit', handleStatusCheck);
}

// Handle status check
async function handleStatusCheck(e) {
    e.preventDefault();
    
    const form = e.target;
    const registrationNumber = form.querySelector('#registrationNumber').value.trim();
    const resultDiv = document.getElementById('statusResult');
    
    if (!registrationNumber) {
        window.SMP_Utils.showNotification('Mohon masukkan nomor pendaftaran', 'error');
        return;
    }
    
    // Show loading
    resultDiv.innerHTML = '<p><i class="fas fa-spinner fa-spin"></i> Mencari data...</p>';
    resultDiv.className = 'status-result';
    resultDiv.style.display = 'block';
    
    try {
        // Simulate API call
        const response = await checkRegistrationStatus(registrationNumber);
        
        if (response.found) {
            displayStatusResult(response.data, resultDiv);
        } else {
            resultDiv.innerHTML = '<p><i class="fas fa-exclamation-triangle"></i> Nomor pendaftaran tidak ditemukan</p>';
            resultDiv.className = 'status-result error';
        }
    } catch (error) {
        console.error('Status check error:', error);
        resultDiv.innerHTML = '<p><i class="fas fa-exclamation-triangle"></i> Terjadi kesalahan saat mengecek status</p>';
        resultDiv.className = 'status-result error';
    }
}

// Simulate status check API
async function checkRegistrationStatus(registrationNumber) {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Simulate different responses based on registration number
    const lastDigit = registrationNumber.slice(-1);
    
    if (lastDigit === '0') {
        return { found: false };
    }
    
    const statuses = ['pending', 'approved', 'rejected'];
    const status = statuses[parseInt(lastDigit) % 3];
    
    return {
        found: true,
        data: {
            registration_number: registrationNumber,
            full_name: 'Contoh Nama Siswa',
            status: status,
            registration_date: '2025-01-15',
            notes: status === 'rejected' ? 'Dokumen tidak lengkap' : ''
        }
    };
}

// Display status result
function displayStatusResult(data, resultDiv) {
    const statusText = {
        pending: 'Menunggu Verifikasi',
        approved: 'Diterima',
        rejected: 'Ditolak'
    };
    
    const statusClass = {
        pending: 'pending',
        approved: 'success',
        rejected: 'error'
    };
    
    const statusIcon = {
        pending: 'fas fa-clock',
        approved: 'fas fa-check-circle',
        rejected: 'fas fa-times-circle'
    };
    
    resultDiv.innerHTML = `
        <div style="text-align: left;">
            <h4><i class="${statusIcon[data.status]}"></i> Status: ${statusText[data.status]}</h4>
            <p><strong>Nomor Pendaftaran:</strong> ${data.registration_number}</p>
            <p><strong>Nama:</strong> ${data.full_name}</p>
            <p><strong>Tanggal Daftar:</strong> ${formatDate(data.registration_date)}</p>
            ${data.notes ? `<p><strong>Catatan:</strong> ${data.notes}</p>` : ''}
        </div>
    `;
    
    resultDiv.className = `status-result ${statusClass[data.status]}`;
}

// Show success modal
function showSuccessModal(registrationNumber) {
    const modal = document.getElementById('successModal');
    const regNumberSpan = document.getElementById('regNumber');
    
    regNumberSpan.textContent = registrationNumber;
    modal.style.display = 'block';
    
    // Close modal when clicking outside
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            closeModal();
        }
    });
}

// Close modal
function closeModal() {
    const modal = document.getElementById('successModal');
    modal.style.display = 'none';
}

// Format date for display
function formatDate(dateString) {
    const months = [
        'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    
    const date = new Date(dateString);
    const day = date.getDate();
    const month = months[date.getMonth()];
    const year = date.getFullYear();
    
    return `${day} ${month} ${year}`;
}

// Utility functions for validation
if (!window.SMP_Utils) {
    window.SMP_Utils = {};
}

// Enhanced validation functions
window.SMP_Utils.isValidEmail = function(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
};

window.SMP_Utils.isValidPhone = function(phone) {
    const phoneRegex = /^[0-9+\-\s()]{10,20}$/;
    return phoneRegex.test(phone);
};

// Auto-save form data to localStorage
function autoSaveForm() {
    const form = document.getElementById('registrationForm');
    if (!form) return;
    
    const formData = new FormData(form);
    const data = {};
    
    for (let [key, value] of formData.entries()) {
        if (form.querySelector(`[name="${key}"]`).type !== 'file') {
            data[key] = value;
        }
    }
    
    localStorage.setItem('spmb_form_data', JSON.stringify(data));
}

// Restore form data from localStorage
function restoreFormData() {
    const form = document.getElementById('registrationForm');
    if (!form) return;
    
    const savedData = localStorage.getItem('spmb_form_data');
    if (!savedData) return;
    
    try {
        const data = JSON.parse(savedData);
        
        for (let [key, value] of Object.entries(data)) {
            const field = form.querySelector(`[name="${key}"]`);
            if (field && field.type !== 'file') {
                field.value = value;
            }
        }
    } catch (error) {
        console.error('Error restoring form data:', error);
    }
}

// Initialize auto-save functionality
document.addEventListener('DOMContentLoaded', function() {
    restoreFormData();
    
    const form = document.getElementById('registrationForm');
    if (form) {
        // Save form data every 30 seconds
        setInterval(autoSaveForm, 30000);
        
        // Save on form change
        form.addEventListener('change', autoSaveForm);
        form.addEventListener('input', debounce(autoSaveForm, 1000));
    }
});

// Debounce function
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Clear saved form data after successful submission
function clearSavedFormData() {
    localStorage.removeItem('spmb_form_data');
}

// Export functions for global access
window.SPMB = {
    closeModal,
    clearSavedFormData,
    generateRegistrationNumber,
    checkRegistrationStatus
};

